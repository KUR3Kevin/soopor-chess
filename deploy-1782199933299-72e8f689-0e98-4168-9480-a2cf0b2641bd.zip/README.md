# Soopor Chess

> Cyberpunk chess engine with optional perks

## Concept
A chess implementation with non-standard rules through 5 unique one-time-use abilities ("perks") that change gameplay strategy:

- **Pawn Sprint**: Advance pawn 4 squares on first move
- **Double Turn**: Take two moves per turn (excluding king/queen)
- **Pawn Recall**: Recapture piece when pawn promotes
- **Firewall**: Shield piece from capture for one turn
- **Scan**: Highlight opponent's attack squares

## Improvements Needed
- [ ] Add CPU difficulty levels (current AI uses basic scoring)
- [ ] Implement sound effects for check/move/perks
- [ ] Add mobile responsive layout for phone play
- [ ] Introduce "Classic" mode toggle
- [ ] Add 3D piece animations when capturing

## Getting Started
```bash
python3 -m http.server 8090
cd ~/Documents/Projects/chess-game && open http://localhost:8090
```